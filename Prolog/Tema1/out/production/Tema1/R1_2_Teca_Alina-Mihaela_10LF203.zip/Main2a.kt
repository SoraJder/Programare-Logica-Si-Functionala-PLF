/*
* Enunt: Verificați dacă o listă este un set.
*
* Modelare matematica (cele doua functii sunt in in clasa LinkedList):
*
* functia search(node, value):
*   daca node este gol -> return false, nu a fost gasit value
*   daca node.value == value -> return true, a fost gasit value
*   altfel search(node.next, value) -> continuam sa cautam
*
* functia checkIfListIsASet(node):
*   daca node este gol -> return true, lista e set
*   daca search(node.next, node.data) este true -> return false, exista duplicate in lista
*   altfel checkIfListIsASet(node.next) -> verificam in continuare
*
* */

fun main() {
    val linkedList = LinkedList()

    println("Cate elemente doriti sa introduceti in lista?")
    val numberOfElements = Integer.valueOf(readLine())

    println("Introduceti elementele:")
    if (numberOfElements != 0) {

        for (i in 0 until numberOfElements) {
            val element = Integer.valueOf(readLine())
            linkedList.insert(element)
        }

        if (linkedList.checkIfListIsASet(linkedList.head)) {
            println("Lista data este un set")
        } else {
            println("Lista data nu este set")
        }

        return
    }
    println("Lista goala!")
}