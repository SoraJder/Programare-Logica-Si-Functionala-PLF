class Node(var data: Int) {
    var next: Node? = null
}