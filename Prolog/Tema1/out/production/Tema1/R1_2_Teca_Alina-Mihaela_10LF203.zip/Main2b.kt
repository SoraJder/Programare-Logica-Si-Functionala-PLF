
/*
*Enunt: (b) Inlocuiți al i-lea element al unei liste cu o valoare v.
*
*Modelare matematica:
*
* functia searchAndChange(node,counter,i, value):
*  daca node==null -> i este mai mare decat dimensiunea listei
*  daca i==counter -> node.data=value, a avut loc cu succes schimbare valorii
*  altfel searchAndChange(node.next, counter+1, i,value) - continuam sa cautam
*
* functia print(node):
* daca node==null -> am ajuns la finalul listei
* altfel afisam node.data si print(node.next) -> continuam sa afisam si elementele ramase
*
*/

fun main(){

    val linkedList = LinkedList()

    println("Cate elemente doriti sa introduceti in lista?")
    val numberOfElements = Integer.valueOf(readLine())

    println("Introduceti elementele:")
    if (numberOfElements != 0) {
        for (i in 0 until numberOfElements) {
            val element = Integer.valueOf(readLine())
            linkedList.insert(element)
        }

        println("Inainte de apelarea functiei aceasta este lista")
        linkedList.print(linkedList.head)

        println("Introduceti pozitia elementului ce il doriti schimbat:")
        val i=Integer.valueOf(readLine())

        println("Inroduceti noua valoare:")
        val value=Integer.valueOf(readLine())
        
        linkedList.searchAndChange(linkedList.head,1,i,value)
        println("Dupa apelarea functiei, aceasta este lista")

        linkedList.print(linkedList.head)

        return
    }
    println("Lista goala!")
}